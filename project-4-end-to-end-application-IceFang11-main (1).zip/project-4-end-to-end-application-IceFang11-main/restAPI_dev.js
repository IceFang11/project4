//restAPI_dev.js
var express = require("express");
var app = express();

const fs = require('fs')
let rawdata = fs.readFileSync('./db.json');
let employee = JSON.parse(rawdata);




app.get('/api', (req, res) => {
  let outputJSON = {
    employees : employeep["data"]
  }
  res.json(outputJSON);
})

app.get('/api/by_name/:qname', (req,res) => {
  let query = req.params['qname']
  filtered_employees = employee["data"].filter(q => q.employee_name.includes(query))
  let outputJSON = {
    employees : filtered_employees
                   }
   res.json(outputJSON);
})

app.get('/api/by_age/:start_age/:end_age', (req,res) => {
  let start_age = req.params['start_age']
  let end_age = req.params[' end_age']
    filtered_employees = employee["data"].filter(
      q => { 
        if ((q.employee_age > parseInt(start_age)) && (q.employee_age < parseInt(end_age)) {
          return true;
        }
          return false;
      }
      };
let outputJSON = {
employees : filtered_employees
}
res.json(outputJSON)
})

app.use('/demo',express.static('front_end'));

app.listen(3000, function() {
  console.log("Server is running")
  console.log(employee);
})
