[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/WfK7U5uP)
# Programming Assignment/Project Submission Template 
Complete all information in the `Student Information` and the `Academic Integrity Acknowledgment` sections. Do not remove any of the text provided. Missing information from your README.md file might result to not accepting the submission or get a zero score for the submission.

## 👤 Student Information

- **Name:** [Deonte Newland]  
- **X-Number:** [X03688836]  
- **Course Code:** [e.g. CUS 1172]  
- **Assignment ID:** [e.g. Project 4 - ]  
- **Assignment Description:** [End-to-End RESTful API Web Application
In the video lesson “Sample Application: Building a RESTful API End-to-End,” I showcased how to apply the concepts introduced in earlier modules on both back-end and front-end development to build an end-to-end Restful API application. The lesson demonstrated how to:

Build a basic REST API back-end (PART A)

Implement a simple front-end interface that consumes API endpoints (Part B)

Organize routes into separate modules for a cleaner project structure (Part C)

This project requires you to review the lesson carefully, then reproduce, extend, and deploy the sample application using the same technologies, syntax, and organizational patterns demonstrated in the video.

 

Project Objectives
You will:

Rebuild the sample RESTful API application exactly as shown in the lesson (Code must be organized into Modules as illustrated in PART C).

Enhance the front-end by adding CSS styling and Bootstrap components to improve layout and user experience.

Deploy your completed application to the Vercel platform (https://vercel.com/).

Research and troubleshoot the deployment process independently, documenting each step you take.

Project Requirements
Your submission must meet the following criteria:

Application Functionality
The application must fully implement all features demonstrated in the video lesson.

You must use the same JavaScript syntax, patterns, and features introduced in the lesson.

Your source code must be organized into modules exactly as demonstrated in Part C of the lesson.

This includes separating routes into their own module(s)

Using the same folder structure and import/export patterns shown in the example

Maintaining clean, readable, and modular code organization

The application must run correctly without errors, both locally and on Vercel.

Local Development Requirements
The instructor must be able to clone your private GitHub repository and run the Node server locally.

Your README.md file must include clear instructions for:

Cloning the repository

Installing dependencies

Running the application locally

Deployment Requirements
Your application must be deployed on Vercel, fully functional, and accessible via a public deployment URL.

You are required to research independently how to deploy a Node-based REST API and front-end to Vercel.

This includes learning how Vercel handles serverless functions, routing, environment configuration, and project structure.

You must troubleshoot any issues you encounter during deployment on your own using documentation, tutorials, and other credible resources.

Your GitHub repository must include a Deployment.md file that documents:

The steps you followed to deploy the application

Any issues you encountered

Resources you used to troubleshoot or learn the deployment process

Repository Requirements
All source code must be stored in the private GitHub repository provided for this project.

Do not upload your code to any public repository.

Your repo must include:

README.md

Deployment.md

All source code for both front-end and back-end

What to Submit
You must submit a cover page that includes:

A direct link to your private GitHub repository containing:

All source code

README.md

Deployment.md

The Vercel deployment URL where your application is live and functional

The instructor should be able to click both links to review your code and test your deployed application.]
- **Instructor**: Dr. Christoforos Christoforou

---

## ✅ Academic Integrity Acknowledgment

By submitting this assignment, I confirm the following:

- This submission is **entirely my own work**.
- I have **not used any AI tools** (including code generators or assistants) to produce or modify the code.
- I **understand all code** included in this submission and am prepared to **explain it in class** if asked.

*Signature:* [Deonte Newland]  
*Date:* [12/15/2025]

---
